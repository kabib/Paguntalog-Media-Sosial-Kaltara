<?php
include('session.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="img/favicon.png">
    <title>PaguntaLOG</title>
    <!-- Bootstrap core CSS -->
    <link href="bootstrap-3.3.5/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/animate.min.css" rel="stylesheet">
    <link href="font-awesome-4.4.0/css/font-awesome.min.css" rel="stylesheet">
    <link href="assets/css/timeline.css" rel="stylesheet">
    <script src="assets/js/jquery.1.11.1.min.js"></script>
    <script src="bootstrap-3.3.5/js/bootstrap.min.js"></script>
    <script src="assets/js/custom.js"></script>
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body class="animated fadeIn">

    <!-- Fixed navbar -->
    <nav class="navbar navbar-default navbar-fixed-top navbar-principal">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="profil.php">
            <img src="img/logo.png" class="img-logo">
            <b>PaguntaLOG</b>
          </a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
			<div class="col-md-5 col-sm-4">         
			 <form class="navbar-form" action="cari.php" method="post">
			    <div class="form-group" style="display:inline;">
			      <div class="input-group" style="display:table;">
			        <input class="form-control" name="search" placeholder="Cari" autocomplete="off" type="text">
			        <span class="input-group-addon" style="width:1%;">
			          <span class="glyphicon glyphicon-search"></span>
			        </span>
			      </div>
			    </div>
			  </form>
			</div>        
			<ul class="nav navbar-nav navbar-right">
				<li class="active">
					<a href="profil.php">
						<?php echo $login_session; ?>
						<img src="images/<?php echo $login_foto; ?>" class="img-nav">
					</a>
				</li>

					<li ><a href="mention.php"><i class="fa fa-globe"></i></a></li>
				<li><a href="logout.php"><i class="fa fa-user"></i> Keluar</a></li>				
			</ul>
        </div>
      </div>
    </nav>

    <!-- Timeline content -->
    <div class="container">
	    <!-- cover content -->
	    <div class="row">
	      <div class="col-md-10 no-paddin-xs">
	      	<!-- cover and profile image-->
	        <div class="col-md-12 col-sm-12 col-xs-12 cover-content">
				<div class="cover-container" style="background-image:url(images/<?php echo $login_cover; ?>);">
					<div class="social-cover"></div>
					<div class="social-desc">
					   <div class="desc-content">
					      <h1 class="fg-white text-shadow"><?php echo $login_alamat; ?></h1>
					      <h5 class="fg-white text-shadow">Handphone : <?php echo $login_nohp; ?></h5>
					      <div style="margin-top:50px;"></div>
					   </div>
					</div>
					<div class="social-avatar" >
					   <img class="img-avatar" src="images/<?php echo $login_foto; ?>" height="100" width="100">
					   <h4 class="fg-white text-center text-shadow"><?php echo $login_lengkap; ?>    <img src="<?php echo $login_terverifikasi; ?>" title="Akun Terverifikasi"></h4>
					   <h5 class="fg-white text-center" style="opacity:0.8;">@<?php echo $login_session; ?></h5>
					   <hr class="border-black75 text-shadow" style="border-width:2px;" >
					   <div class="text-center">
					    <button role="button" class="btn btn-inverse btn-outlined btn-retainBg btn-brightblue" type="button">
					      <span>ikuti aku</span>
					    </button>
					   </div>
					</div>
				</div>
	        </div><!-- end cover and profile image-->
	        <!-- cover menu -->
	        <div class="col-md-12  col-sm-12 col-xs-12">
	          <div class="panel-options">
	            <div class="navbar navbar-default navbar-cover">
	              <div class="container-fluid">
	                <div class="navbar-header">
	                  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#profile-opts-navbar">
	                    <span class="sr-only">Toggle navigation</span>
	                    <span class="icon-bar"></span>
	                    <span class="icon-bar"></span>
	                    <span class="icon-bar"></span>
	                  </button>
	                </div>

	                <div class="collapse navbar-collapse" id="profile-opts-navbar">
	                  <ul class="nav navbar-nav navbar-right">
	                    <li><a href="profil.php"><i class="fa fa-tasks"></i>Tembok Saya</a></li>
                         <li><a href="temboksemua.php"><i class="fa fa-tasks"></i>Tembok Semua</a></li>
	                    <li><a href="editakun.php?id=<?php echo $login_id; ?>"><i class="fa fa-info-circle"></i>Edit Akun</a></li>
	                    <li  class="active"><a href="sahabat.php"><i class="fa fa-users"></i>Sahabat</a></li>
	                         <li><a href="gambar.php"><i class="fa fa-file-image-o"></i>Galeri</a></li>
	                   
	                  </ul>
	                </div>
	              </div>
	            </div>
	          </div>
	        </div><!-- cover menu -->
	      </div>
	    </div><!-- cover content -->
      
      
      <div class="row">
        <div class="col-md-10 no-paddin-xs">
          <div class="col-md-12">
            <!-- panel friends -->
            <div class="panel panel-white panel-list-friends">
              <div class="panel-heading">
                <h3 class="panel-title">Sahabat PaguntaLOG</h3>
              </div>
              <div class="panel-body">
                <?php 
		include("koneksi.php");
		$tampil = mysql_query("select * from akun");
		while($data=mysql_fetch_array($tampil)){
		
			?> 
                <div class="col-md-4">
                  <div class="g-hover-card">
                    <img src="images/<?=$data['cover']?>" alt="">
                    <div class="user-avatar">
                      <img src="images/<?=$data['foto']?>" alt="">
                    </div>
                    <div class="info">
                      <div class="title">
                        <a href="temanku.php?id=<?php echo $data['id_akun']; ?>"><?=$data['namalengkap']?></a>
                      </div>
                    </div>
                     <div class="title">
                        @<?=$data['nama']?>
                      </div><br/>
                  </div>
                </div>
<?php
}
?>
             
              </div>
            </div><!-- end panel friends -->
          </div>
        </div>        
      </div>
    </div>

    <footer class="welcome-footer">
      <div class="container">
        <p>
          <div class="footer-links">

            <a href="#">Tim Pengembang</a> | 
            <a href="#">Kontak</a> | 
            <a href="#">Tentang Kami</a>
          </div>   
          Copyright &copy; Tarakan Creative - All rights reserved       
        </p>
      </div>
    </footer>
<script type="text/javascript">
  var _gaq = [
    ['_setAccount', 'UA-49755460-1'],
    ['_trackPageview']
  ];
  (function (d, t) {
    var g = d.createElement(t), s = d.getElementsByTagName(t)[0];
    g.src = ('https:' == location.protocol ? '//ssl' : '//www') + '.google-analytics.com/ga.js';
    s.parentNode.insertBefore(g, s)
  }(document, 'script'));
</script>	
  </body>
</html>