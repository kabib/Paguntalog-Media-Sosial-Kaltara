<?php
include "koneksi.php";

	$id_akun = $_POST['id_akun'];
	$namalengkap = $_POST['namalengkap'];
	$alamat = $_POST['alamat'];
	$no_hp = $_POST['nohp'];
	$tentang = $_POST['tentang'];
	$email = $_POST['email'];
	if(!empty($_FILES['fupload']["tmp_name"])){
	//ganti foto
	
	$photo_lama=@$_POST['photo_lama'];
	$nama_file=@$_FILES['fupload']['name'];

	$lokasi_file = "images/";
	$file_upload = $lokasi_file . $nama_file;
	move_uploaded_file($_FILES["fupload"]["tmp_name"],$file_upload);
	mysql_query("UPDATE akun SET foto	= '$nama_file',
								namalengkap	= '$namalengkap',
								email	= '$email',
								tentang	= '$tentang',
								alamat	= '$alamat',
								no_hp	= '$no_hp'
                                    WHERE id_akun		= '$id_akun'");
					header("location: profil.php");
	}elseif(!empty($_FILES['fuploadcover']["tmp_name"])){
	//ganti cover
	
	$photo_lama1=@$_POST['photo_lama'];
	$nama_file1=@$_FILES['fuploadcover']['name'];

	$lokasi_file1 = "images/";
	$file_upload1 = $lokasi_file1 . $nama_file1;
	move_uploaded_file($_FILES["fuploadcover"]["tmp_name"],$file_upload1);
	mysql_query("UPDATE akun SET cover	= '$nama_file1',
								namalengkap	= '$namalengkap',
								email	= '$email',
								tentang	= '$tentang',
								alamat	= '$alamat',
								no_hp	= '$no_hp'
                                    WHERE id_akun		= '$id_akun'");
											header("location: profil.php");
				
	}
	elseif(!empty($_FILES['fupload']["tmp_name"]) && !empty($_FILES['fupload']["tmp_name"])){
	//ganti foto
	
	$photo_lama=@$_POST['photo_lama'];
	$nama_file=@$_FILES['fupload']['name'];

	$lokasi_file = "images/";
	$file_upload = $lokasi_file . $nama_file;
	move_uploaded_file($_FILES["fupload"]["tmp_name"],$file_upload);
	mysql_query("UPDATE akun SET foto	= '$nama_file',
								namalengkap	= '$namalengkap',
								email	= '$email',
								tentang	= '$tentang',
								alamat	= '$alamat',
								no_hp	= '$no_hp'
                                    WHERE id_akun		= '$id_akun'");
	//ganti cover
	
	$photo_lama1=@$_POST['photo_lama'];
	$nama_file1=@$_FILES['fuploadcover']['name'];

	$lokasi_file1 = "images/";
	$file_upload1 = $lokasi_file1 . $nama_file1;
	move_uploaded_file($_FILES["fuploadcover"]["tmp_name"],$file_upload1);
		mysql_query("UPDATE akun SET cover	= '$nama_file1',
									foto	= '$nama_file',
								namalengkap	= '$namalengkap',
								email	= '$email',
								tentang	= '$tentang',
								alamat	= '$alamat',
								no_hp	= '$no_hp'
                                    WHERE id_akun		= '$id_akun'");
											
											$photo_lama1=@$_POST['photo_lama'];
	$nama_file1=@$_FILES['fuploadcover']['name'];

	$lokasi_file1 = "images/";
	$file_upload1 = $lokasi_file1 . $nama_file1;
	move_uploaded_file($_FILES["fuploadcover"]["tmp_name"],$file_upload1);
	mysql_query("UPDATE akun SET cover	= '$nama_file1',
								namalengkap	= '$namalengkap',
								email	= '$email',
								tentang	= '$tentang',
								alamat	= '$alamat',
								no_hp	= '$no_hp'
                                    WHERE id_akun		= '$id_akun'");
											header("location: profil.php");
	}
			
			else {
			
			mysql_query("UPDATE akun SET namalengkap	= '$namalengkap',
								email	= '$email',
								tentang	= '$tentang',
								alamat	= '$alamat',
								no_hp	= '$no_hp'
                                    WHERE id_akun		= '$id_akun'");
											header("location: profil.php");
			
			}	
	
?>
