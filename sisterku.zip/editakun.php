
<?php
include('session.php');
include("koneksi.php");
$query = "select * from akun where id_akun = '$_GET[id]'";
$result = mysql_query($query);
$data = mysql_fetch_array($result);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="img/favicon.png">
    <title>PaguntaLOG</title>
    <!-- Bootstrap core CSS -->
    <link href="bootstrap-3.3.5/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/animate.min.css" rel="stylesheet">
    <link href="font-awesome-4.4.0/css/font-awesome.min.css" rel="stylesheet">
    <link href="assets/css/timeline.css" rel="stylesheet">
    <script src="assets/js/jquery.1.11.1.min.js"></script>
    <script src="bootstrap-3.3.5/js/bootstrap.min.js"></script>
    <script src="assets/js/custom.js"></script>
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body class="animated fadeIn">

    <!-- Fixed navbar -->
    <nav class="navbar navbar-default navbar-fixed-top navbar-principal">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="profil.php">
            <img src="img/logo.png" class="img-logo">
            <b>PaguntaLOG</b>
          </a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
			<div class="col-md-5 col-sm-4">         
			 <form class="navbar-form" action="cari.php" method="post">
			    <div class="form-group" style="display:inline;">
			      <div class="input-group" style="display:table;">
			        <input class="form-control" name="search" placeholder="Cari" autocomplete="off" type="text">
			        <span class="input-group-addon" style="width:1%;">
			          <span class="glyphicon glyphicon-search"></span>
			        </span>
			      </div>
			    </div>
			  </form>
			</div>        
			<ul class="nav navbar-nav navbar-right">
				<li class="active">
					<a href="profil.php">
						<?php echo $login_session; ?> <img src="images/<?php echo $login_foto; ?>" class="img-nav">
					</a>
				</li>

			
				<li><a href="mention.php"><i class="fa fa-globe"></i></a></li>
				<li><a href="logout.php"><i class="fa fa-user"></i> Keluar</a></li>				
			</ul>
        </div>
      </div>
    </nav>
<!-- Timeline content -->
<div class="container container-timeline" style="margin-top:100px;">
    	<div class="col-md-10 no-paddin-xs">
			<!-- left content-->
    		<div class="col-md-10 col-md-offset-2 no-paddin-xs">
            <form action="edit_aksi.php" method="post" enctype="multipart/form-data">
			    <!-- update cover and profile image-->
                <input name="photo_lama" type="hidden" id="gambar" value="<?php echo $data['foto']; ?>"/>
                <input name="photo_lama1" type="hidden" id="gambar" value="<?php echo $data['cover']; ?>"/>
		    <div class="panel panel-white post panel-shadow">
					  <div class="post-heading">
					      <div class="pull-left image">
					          <img src="images/<?php echo $data['foto']; ?>" class="avatar" alt="user profile image">
					      </div>
					      <div class="pull-left meta">
							<input name="fupload" type="file" id="gambar" />
					      </div>
					  </div>
					  <div class="post-image">
					      <img src="images/<?php echo $data['cover']; ?>" class="image show-in-modal" alt="image post">
					  </div>
					  <div class="post-description">
					  	<input name="fuploadcover" type="file" id="gambar" />
					  </div>
					</div><!-- end update cover and profile image-->
			    <!-- update info -->
					<div class="panel panel-white post panel-shadow">
					  <div class="panel-body">
						
						  <div class="form-group">
						    <label class="col-md-3 control-label">Nama Lengkap</label>
						    <div class="col-md-8">
						      <input name="namalengkap" type="text" class="form-control" id="namalengkap" value="<?php echo $data['namalengkap']; ?>">
						    </div>
						  </div>
                    
                           <div class="form-group">
						    <label class="col-md-3 control-label">Alamat</label>
						    <div class="col-md-8">
						      <input name="alamat" type="text" class="form-control" id="alamat" value="<?php echo $data['alamat']; ?>">
						    </div>
					    </div>
                    
                           <div class="form-group">
						    <label class="col-md-3 control-label">No HP</label>
						    <div class="col-md-8">
						      <input name="nohp" type="text" class="form-control" id="nohp" value="<?php echo $data['no_hp']; ?>">
						    </div>
						  </div>
                             <div class="form-group">
						    <label class="col-md-3 control-label">Tentang</label>
						    <div class="col-md-8">
						      <textarea name="tentang" class="form-control" id="tentang"><?php echo $data['tentang']; ?></textarea>
                              <input name="id_akun" type="hidden" value="<?php echo $data['id_akun']; ?>">
						    </div>
						  </div>
                          <br/>
						 
						  <div class="form-group">
						    <label class="col-md-3 control-label">Email</label>
						    <div class="col-md-8">
						      <input name="email" type="text" class="form-control" id="email" value="<?php echo $data['email']; ?>">
                               <input name="id_akun" type="hidden" class="form-control" id="email" value="<?php echo $data['id_akun']; ?>">
						    </div>
						  </div>
					  </div>
					</div><!-- end update info-->

					<div class="panel panel-white post-load-more panel-shadow text-center">
						<button class="btn btn-success" name="save">
							Simpan
						</button>
					</div>				
				</form>
   		  </div><!-- end left content--> 
    	</div>
    </div>

    
    
    
    <footer class="welcome-footer">
      <div class="container">
        <p>
          <div class="footer-links">

            <a href="#">Tim Pengembang</a> | 
            <a href="#">Kontak</a> | 
            <a href="#">Tentang Kami</a>
          </div>   
          Copyright &copy; Tarakan Creative - All rights reserved       
        </p>
      </div>
    </footer>
<script type="text/javascript">
  var _gaq = [
    ['_setAccount', 'UA-49755460-1'],
    ['_trackPageview']
  ];
  (function (d, t) {
    var g = d.createElement(t), s = d.getElementsByTagName(t)[0];
    g.src = ('https:' == location.protocol ? '//ssl' : '//www') + '.google-analytics.com/ga.js';
    s.parentNode.insertBefore(g, s)
  }(document, 'script'));
</script>	
  </body>

</html>
