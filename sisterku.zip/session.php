<?php
// Membangun Koneksi dengan Server dengan nama server, user_id dan password sebagai parameter
$connection = mysql_connect("localhost", "root", "");
// Seleksi Database
$db = mysql_select_db("sisterku", $connection);
session_start();// Memulai Session
// Menyimpan Session
$user_check=$_SESSION['login_user'];
// Ambil nama karyawan berdasarkan username karyawan dengan mysql_fetch_assoc
$ses_sql=mysql_query("select nama, namalengkap, id_akun, no_hp, alamat,  foto, cover, terverifikasi,  tentang from akun where nama='$user_check'", $connection);
$row = mysql_fetch_assoc($ses_sql);
$login_session =$row['nama'];
$login_id =$row['id_akun'];
$login_nohp =$row['no_hp'];
$login_alamat =$row['alamat'];
$login_foto =$row['foto'];
$login_lengkap =$row['namalengkap'];
$login_cover =$row['cover'];
$login_tentang =$row['tentang'];
$login_terverifikasi =$row['terverifikasi'];

if(!isset($login_session)){
mysql_close($connection); // Menutup koneksi
header('Location: profil.php'); // Mengarahkan ke Home Page
}

?>