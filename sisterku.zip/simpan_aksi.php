

<?php
include("koneksi.php");
$foto = "No_Photo_Available.jpg";
$cover = "coverwrong.jpg";
$terverifikasi = "belum.png";
$password = md5($_POST[password]);
$query = "insert into akun (nik, nama, namalengkap, alamat, email, password, foto, cover, terverifikasi) values ('$_POST[nik]', '$_POST[username]', '$_POST[namalengkap]', '$_POST[alamat]', '$_POST[email]', '$password', '$foto', '$cover', '$terverifikasi')";
$result = mysql_query($query);

if ($result) {
	header("location: index.php");
}
else {
	echo "proses simpan gagal !.";
}
?>