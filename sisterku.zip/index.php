
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="img/favicon.png">
    <title>PaguntaLOG</title>
    <!-- Bootstrap core CSS -->
    <link href="bootstrap-3.3.5/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/animate.min.css" rel="stylesheet">
    <link href="font-awesome-4.4.0/css/font-awesome.min.css" rel="stylesheet">
    <link href="assets/css/timeline.css" rel="stylesheet">
    <script src="assets/js/jquery.1.11.1.min.js"></script>
    <script src="bootstrap-3.3.5/js/bootstrap.min.js"></script>
    <script src="assets/js/custom.js"></script>
  <script type="text/javascript">
    $(document).ready(function() {
        $('.but').trigger('click');
    })
</script>
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    
  </head>
  <body class="welcome-page animated fadeIn" >
 
    <!-- Fixed navbar -->
    <nav class="navbar navbar-default navbar-fixed-top navbar-principal welcome-nav">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="/sisterku">
            <img src="img/logo.png" class="img-logo">
            <b>PaguntaLOG</b>
          </a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
          <ul class="nav navbar-nav navbar-right">
              <form class="navbar-form form-login" role="form" action="login.php" method="post">
                  <div class="form-group">
                      <input type="text" class="form-control" name="nama" placeholder="Username">
                  </div>
                  <div class="form-group">
                      <input type="password" class="form-control" name="password" placeholder="Password">
                  </div>
                  <button type="submit" class="btn btn-default btn-login" name="submit">Login</button>
              </form>     
          </ul>        
        </div>
      </div>
    </nav><!-- end fixed nav-->
    <div class="row-welcome" style="background-image: url('img/Bg/home-bg.jpg');">
      <div class="row-body">
        <div class="welcome-inner">
          <!-- welcome message -->
          <div class="welcome-message"><br/><br/><br/>
            <div class="welcome-desc">
              Selamat Datang di PaguntaLOG
            </div>
            <div class="welcome-desc">
              Menuju Tarakan Smart City
            </div>
            <div class="welcome-about">
              Menemui Masalah Dalam Masyarakat, Ayo Bagikan
            </div>                        
          </div><!-- end welcome message-->
          <!-- register and login form-->
          <div class="welcome-inputs">
            <div class="panel panel-success panel-inputs animated fadeInLeft panel-login">
              <div class="panel-heading">
                <h3 class="panel-title">Register</h3>
              </div>
              <div class="panel-body">
              
                                                                                                                             </form>
                <form action="simpan_aksi.php" method="post" >
                <input type="text" id="short" name="nik" placeholder="NIK">
                  <input type="text" id="short" name="username" placeholder="Username">
                  <input type="text" id="short" name="namalengkap" placeholder="Nama Lengkap">
                  <input type="text" id="short" name="alamat" placeholder="Alamat">
                  <input type="password" id="short" name="password" placeholder="Password">
                  <input type="text" id="short" name="email" placeholder="Email">
              
                  <button type="submit" name="register" class="btn btn-success">
                    <i class="fa fa-user-plus"></i>
                    Register
                  </button>
                </form> 
              </div>
            </div>          
             
          </div><!-- end register and login form -->
        </div>
      </div>
    </div>
  <button data-toggle="modal" data-target="#myModal" style="display:none;" class="but"></button>
  <!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content--><br/><br/><br/><br/>
    <div class="modal-content">
      <div class="modal-header" >
       
       
          <img src="img/Photos/3.jpg" class="img-logo">
       
      </div>
     
      <div class="modal-footer">
       <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
    </div>

  </div>
</div>
<div class="welcome-full animated fadeInLeft">
      <div class="row-body">
        <!-- some registered users -->
        <div class="welcome-users-inner">
         <marquee behavior="ALTERNATE">  <?php 
include("koneksi.php");
		$tampil = mysql_query("select * from status ");
		while($data=mysql_fetch_array($tampil)){
		
			?> 
         <div class="welcome-user">
         
            <a href="index.php" onClick="return confirm('Silahkan Daftar Dulu')"> 
              <img src="<?=$data['gambar']?>" width="120" class="img-rounded" />
            </a>          </div>
          <?php
		  }
		  ?></marquee>
        
        </div><!-- some registered users -->
      </div>
    </div>
     <footer class="welcome-footer">
      <div class="container">
        <p>
          <div class="footer-links">

            <a href="#myModal" data-toggle="modal" >Tim Pengembang</a> | 
            <a href="#">Kontak</a> | 
            <a href="#">Tentang Kami</a>
          </div>   
          Copyright &copy; Tarakan Creative - All rights reserved       
        </p>
      </div>
    </footer>
<script type="text/javascript">
  var _gaq = [
    ['_setAccount', 'UA-49755460-1'],
    ['_trackPageview']
  ];
  (function (d, t) {
    var g = d.createElement(t), s = d.getElementsByTagName(t)[0];
    g.src = ('https:' == location.protocol ? '//ssl' : '//www') + '.google-analytics.com/ga.js';
    s.parentNode.insertBefore(g, s)
  }(document, 'script'));
</script>	
  </body>

</html>
