<?php
	session_start();
	function logged_in() {
		return isset($_SESSION['member_id']);
        
	}
	function confirm_logged_in() {
		if (!logged_in()) {?>
			<script type="text/javascript">
				window.location = "index.php";
			</script>
		<?php
		}
	}
?>
