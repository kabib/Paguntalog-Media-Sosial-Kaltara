<?php
include("koneksi.php");
$ambil_data = mysql_query("select * from akun where id_akun='$_GET[id]'",$koneksi);
$hasil_data = mysql_fetch_array($ambil_data);
?>

<?php
include('session.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="img/favicon.png">
    <title>PaguntaLOG</title>
    <!-- Bootstrap core CSS -->
    <link href="bootstrap-3.3.5/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/animate.min.css" rel="stylesheet">
    <link href="font-awesome-4.4.0/css/font-awesome.min.css" rel="stylesheet">
    <link href="assets/css/timeline.css" rel="stylesheet">
    <script src="assets/js/jquery.1.11.1.min.js"></script>
    <script src="bootstrap-3.3.5/js/bootstrap.min.js"></script>
    <script src="assets/js/custom.js"></script>
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body class="animated fadeIn">

    <!-- Fixed navbar -->
    <nav class="navbar navbar-default navbar-fixed-top navbar-principal">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="profil.php">
            <img src="img/logo.png" class="img-logo">
            <b>PaguntaLOG</b>
          </a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
			<div class="col-md-5 col-sm-4">         
			 <form class="navbar-form" action="cari.php" method="post">
			    <div class="form-group" style="display:inline;">
			      <div class="input-group" style="display:table;">
			        <input class="form-control" name="search" placeholder="Cari" autocomplete="off" type="text">
			        <span class="input-group-addon" style="width:1%;">
			          <span class="glyphicon glyphicon-search"></span>
			        </span>
			      </div>
			    </div>
			  </form>
			</div>        
			<ul class="nav navbar-nav navbar-right">
				<li class="active">
					<a href="profil.php">
						<?php echo $login_session; ?>
						<img src="images/<?php echo $login_foto; ?>" class="img-nav">
					</a>
				</li>

	
					<li ><a href="mention.php"><i class="fa fa-globe"></i></a></li>
				<li><a href="logout.php"><i class="fa fa-user"></i> Keluar</a></li>				
			</ul>
        </div>
      </div>
    </nav>


    <!-- Timeline content -->
    <div class="container">
      <!-- cover content -->
      <div class="row">
        <div class="col-md-10 no-paddin-xs">
          <!-- cover and profile image-->
          <div class="col-md-12 col-sm-12 col-xs-12 cover-content">
            <div class="cover-container" style="background-image:url(images/<?=$hasil_data['cover']?>);">
              <div class="social-cover"></div>
              <div class="social-desc">
                 <div class="desc-content">
                    <h1 class="fg-white text-shadow"><?=$hasil_data['alamat']?></h1>
                    <h5 class="fg-white text-shadow">Handphone : <?=$hasil_data['no_hp']?></h5>
                    <div style="margin-top:50px;"></div>
                 </div>
              </div>
              <div class="social-avatar" >
                 <img class="img-avatar" src="images/<?=$hasil_data['foto']?>" height="100" width="100">
                 <h4 class="fg-white text-center text-shadow"><?=$hasil_data['namalengkap']?> <img src="<?=$hasil_data['terverifikasi']?>"></h4>
                 <h5 class="fg-white text-center" style="opacity:0.8;">@<?=$hasil_data['nama']?></h5>
                 <hr class="border-black75 text-shadow" style="border-width:2px;" >
                 <div class="text-center">
                  <button role="button" class="btn btn-inverse btn-outlined btn-retainBg btn-brightblue" type="button">
                    <span>ikuti saya</span>
                  </button>
                 </div>
              </div>
            </div>
          </div><!-- end cover and profile image-->
          <!-- cover menu -->
          <div class="col-md-12  col-sm-12 col-xs-12">
            <div class="panel-options">
              <div class="navbar navbar-default navbar-cover">
                <div class="container-fluid">
                  <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#profile-opts-navbar">
                      <span class="sr-only">Toggle navigation</span>
                      <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                    </button>
                  </div>

                  <div class="collapse navbar-collapse" id="profile-opts-navbar">
                    <ul class="nav navbar-nav navbar-right">
                      <li ><a href="profil.php"><i class="fa fa-tasks"></i>Tembok Saya</a></li>
                         <li><a href="temboksemua.php"><i class="fa fa-tasks"></i>Tembok Semua</a></li>
	                    <li><a href="editakun.php?id=<?php echo $login_id; ?>"><i class="fa fa-info-circle"></i>Edit Akun</a></li>
	                    <li><a href="sahabat.php"><i class="fa fa-users"></i>Sahabat</a></li>
	                    <li><a href="gambar.php"><i class="fa fa-file-image-o"></i>Galeri</a></li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div><!-- cover menu -->
        </div>
      </div><!-- cover content -->
      <div class="row">
        <div class="col-md-10 no-paddin-xs">
          <!-- tabs user info -->
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="panel panel-white panel-about">
              <div class="panel-heading">
                <h3 class="panel-title">Tentang Teman
                
                </h3>
              </div>
              <div class="panel-body">
                <div class="col-md-12 col-sm-12 col-xs-12 about-tab-container">
                  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3 about-tab-menu">
                    <div class="list-group">
                      <a href="#" class="list-group-item active text-center">
                        <h4 class="fa fa-child"></h4><br/>Detail User
                      </a>
                      
                    </div>
                  </div>
                  <div class="col-lg-9 col-md-9 col-sm-9 col-xs-9 about-tab">
                    <!-- Overview section -->
                    <div class="about-tab-content active">
                       <ul class="list-group">
                        <li class="list-group-item"><i class="glyphicon glyphicon-user"></i> NIK : <?=$hasil_data['nik']?></li>
                        <li class="list-group-item"><i class=" glyphicon glyphicon-certificate"></i> Nama : <?=$hasil_data['namalengkap']?></li>
                        <li class="list-group-item"><i class="glyphicon glyphicon-map-marker"></i> Alamat : <?=$hasil_data['alamat']?></li>
                        <li class="list-group-item"><i class="glyphicon glyphicon-envelope"></i> Email: <?=$hasil_data['email']?></li>
                        <li class="list-group-item"><i class="glyphicon glyphicon-phone-alt"></i> NoHandphone : <?=$hasil_data['no_hp']?></li>
                        <li class="list-group-item"><i class="glyphicon glyphicon-user"></i> Tentang : <?=$hasil_data['tentang']?></li>
                       
                      </ul>
                    </div>
                    <!-- Work section -->
                    <div class="about-tab-content">
                       <ul class="list-group">
                        <li class="list-group-item"><i class="fa fa-briefcase"></i>&nbsp; Software developer at <a href="#">Deystrap</a></li>
                        <li class="list-group-item"><i class="fa fa-cubes"></i>&nbsp;Web designer at <a href="#">Dey-Dey</a></li>
                      </ul>
                    </div>

                    <!-- Places search -->
                    <div class="about-tab-content">
                      <ul class="photos">
                        <li>
                            <a href="#">
                              <img src="img/Post/staticmap.html" alt="map 1" class="img-responsive show-in-modal tip">
                            </a>
                        </li>
                      </ul>
                    </div>
                    <!-- Contact section -->
                    <div class="about-tab-content">
                      <ul class="list-group">
                        <li class="list-group-item"><i class="fa fa-phone"></i>&nbsp; 533 44 55</li>
                        <li class="list-group-item"><i class="fa fa-mobile"></i>&nbsp; +57 328 999 444 2</li>
                        <li class="list-group-item"><i class="fa fa-cubes"></i>&nbsp;@username (twitter) <i class="fa fa-twitter text-twitter"></i></li>
                        <li class="list-group-item"><i class="fa fa-envelope"></i>&nbsp; username@email.com</li>
                      </ul>
                    </div>
                    <!-- Events section-->
                    <div class="about-tab-content">
                      <ul class="list-group">
                        <li class="list-group-item"><i class="fa fa-calendar text-danger"></i>&nbsp; <a href="#">August 12 welcome to my like</a></li>
                        <li class="list-group-item"><i class="fa fa-calendar text-danger"></i>&nbsp; <a href="#">August 5 Nach concert at barcelona</a></li>
                        <li class="list-group-item"><i class="fa fa-calendar text-danger"></i>&nbsp; <a href="#">July 13 El grones concert on medellin</a></li>
                        <li class="list-group-item"><i class="fa fa-calendar text-danger"></i>&nbsp; <a href="#">June 30 final of ty</a> </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div><!-- end tabs user info -->
          
          
        </div>
      </div>
    </div>

  
    
      <footer class="welcome-footer">
      <div class="container">
        <p>
          <div class="footer-links">

            <a href="#">Tim Pengembang</a> | 
            <a href="#">Kontak</a> | 
            <a href="#">Tentang Kami</a>
          </div>   
          Copyright &copy; Tarakan Creative - All rights reserved       
        </p>
      </div>
    </footer>
<script type="text/javascript">
  var _gaq = [
    ['_setAccount', 'UA-49755460-1'],
    ['_trackPageview']
  ];
  (function (d, t) {
    var g = d.createElement(t), s = d.getElementsByTagName(t)[0];
    g.src = ('https:' == location.protocol ? '//ssl' : '//www') + '.google-analytics.com/ga.js';
    s.parentNode.insertBefore(g, s)
  }(document, 'script'));
</script>	
  </body>

</html>
