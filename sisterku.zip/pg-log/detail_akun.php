<?php
 include '../koneksi.php';


  include 'kepala.php';

 ?>
		<div class="sidebar-bg"></div>
		<!-- end #sidebar -->
		
		<!-- begin #content -->
<div id="content" class="content">
			<!-- begin breadcrumb -->
			<ol class="breadcrumb pull-right">
				<li><a href="javascript:;">Home</a></li>
				<li><a href="javascript:;">Detail Akun</a></li>
				<li class="active">Pilihan</li>
			</ol>
			<!-- end breadcrumb -->
			<!-- begin page-header -->
			<h1 class="page-header">Detail Akun <small>PaguntaLOG</small></h1>
			<!-- end page-header -->
			<?php
			 $query = "select * from akun where id_akun = '$_GET[id]'";
$result = mysql_query($query);
$data = mysql_fetch_array($result);
?>
			<!-- begin section-container -->
			<div class="section-container section-with-top-border">
			    <h4 class="m-t-0"><?php echo $data['namalengkap']?></h4>
		
            <center><img src="../images/<?php echo $data['foto']?>" width="80" height="80" /></center>
                <form class="form-horizontal" data-parsley-validate="true" name="demo-form" action="aksi_daftar.php" method="post">
                 <div class="form-group">
                        <label class="control-label col-sm-3" for="fullname">NIK <span class="text-danger"></span></label>
                        <div class="col-sm-6">
                           <?php echo $data['nik']?>
                        </div>
                  </div>
                    <div class="form-group">
                        <label class="control-label col-sm-3" for="fullname">Username <span class="text-danger"></span></label>
                        <div class="col-sm-6">
                           <?php echo $data['nama']?>
                        </div>
                    </div>
                     <div class="form-group">
                        <label class="control-label col-sm-3" for="fullname">Nama <span class="text-danger"></span></label>
                        <div class="col-sm-6">
                          <?php echo $data['namalengkap']?>
                        </div>
                    </div>
                     <div class="form-group">
                        <label class="control-label col-sm-3" for="fullname">Alamat <span class="text-danger"></span></label>
                        <div class="col-sm-6">
              <?php echo $data['alamat']?>
                        </div>
                    </div>
                       <div class="form-group">
                        <label class="control-label col-sm-3" for="fullname">Email <span class="text-danger"></span></label>
                        <div class="col-sm-6">
              <?php echo $data['email']?>
                        </div>
                    </div>
                       <div class="form-group">
                        <label class="control-label col-sm-3" for="fullname">NO HP <span class="text-danger"></span></label>
                        <div class="col-sm-6">
              <?php echo $data['no_hp']?>
                        </div>
                    </div>
                     <div class="form-group">
                        <label class="control-label col-sm-3" for="fullname">Tentang Kami<span class="text-danger"></span></label>
                        <div class="col-sm-6">
              <?php echo $data['tentang']?>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-3">Status Terverifikasi <span class="text-danger"></span></label>
                        <div class="col-sm-6">
                            <select class="form-control" id="select-required" name="selectBox" data-parsley-required="true">
                              <option value="belum.png" <?php if($data['terverifikasi'] == 'belum.png'){ echo 'selected'; } ?>>Belum Terverifikasi</option>
                             <option value="terdaftar.png" <?php if($data['terverifikasi'] == 'terdaftar.png'){ echo 'selected'; } ?>>Terverifikasi</option>
                          </select>
                        </div>
                    </div>
               
                    <input type="hidden" name="tid" value="<?php echo $data['id_akun']; ?>" >
                   
                  
                    <div class="form-group m-b-0">
                        <label class="control-label col-sm-3"></label>
                        <div class="col-sm-6">
                            <button type="submit" class="btn btn-success width-xs">Validasi</button>
                        </div>
                    </div>
                </form>
            </div>
            <!-- end section-container -->
            
            <!-- begin section-container -->
			
			 
<?php
  include 'kaki.php';

 ?>
          