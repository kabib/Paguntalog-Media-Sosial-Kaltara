<?php
$connection = mysql_connect("localhost", "root", "");
// Seleksi Database
$db = mysql_select_db("sisterku", $connection);
session_start();// Memulai Session
// Menyimpan Session
$user_check=$_SESSION['login_user'];
// Ambil nama karyawan berdasarkan username karyawan dengan mysql_fetch_assoc
$ses_sql=mysql_query("select username, alamat, email, foto, nama from admin where username='$user_check'", $connection);
$row = mysql_fetch_assoc($ses_sql);
$login_session =$row['username'];
$login_email =$row['email'];
$login_alamat =$row['alamat'];
$login_foto =$row['foto'];
$login_lengkap =$row['nama'];


if(!isset($login_session)){
mysql_close($connection); // Menutup koneksi
header('Location: dashboard.php'); // Mengarahkan ke Home Page
}

?>