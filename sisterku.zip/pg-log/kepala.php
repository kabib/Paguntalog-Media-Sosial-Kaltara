<?php
include('session.php');

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<title>PaguntaLOG Admin Panel</title>
	<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport" />
	<meta content="" name="description" />
	<meta content="" name="author" />
	<link rel="icon" type="image/png" href="assets/img/favicon.png">
	<link href="http://fonts.googleapis.com/css?family=Nunito:400,300,700" rel="stylesheet" id="fontFamilySrc" />
	<link href="assets/plugins/jquery-ui/themes/base/minified/jquery-ui.min.css" rel="stylesheet" />
	<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
	<link href="assets/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet" />
	<link href="assets/css/animate.min.css" rel="stylesheet" />
	<link href="assets/css/style.min.css" rel="stylesheet" />
    <link href="assets/plugins/bootstrap-calendar/css/bootstrap_calendar.css" rel="stylesheet" />
    <link href="assets/plugins/gritter/css/jquery.gritter.css" rel="stylesheet" />	
	<script src="assets/plugins/pace/pace.min.js"></script>

</head>
<body>
	<!-- begin #page-loader -->
	<div id="page-loader" class="page-loader fade in"><span class="spinner">Loading...</span></div>
	<div id="page-container" class="fade page-container page-header-fixed page-sidebar-fixed page-with-two-sidebar page-with-footer">
		<!-- begin #header -->
		<div id="header" class="header navbar navbar-default navbar-fixed-top">
			<!-- begin container-fluid -->
			<div class="container-fluid">
				<!-- begin mobile sidebar expand / collapse button -->
				<div class="navbar-header">
					<a href="dashboard.php" class="navbar-brand"><img src="assets/img/logo.png" class="logo" alt="" /> PaguntaLOG Admin</a>
					<button type="button" class="navbar-toggle" data-click="sidebar-toggled">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
				</div>
				<!-- end mobile sidebar expand / collapse button -->
				
				<!-- begin navbar-right -->
				<ul class="nav navbar-nav navbar-right">
				
					
					<li class="dropdown navbar-user">
						<a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown">
							<span class="image"><img src="<?php echo $login_foto; ?>" alt="" /></span>
							<span class="hidden-xs"><?php echo $login_session; ?></span> <b class="caret"></b>
						</a>
						<ul class="dropdown-menu pull-right">
						
							<li><a href="logout.php">Keluar</a></li>
						</ul>
					</li>
					<li>
						<a href="javascript:;" data-click="right-sidebar-toggled">
							<i class="fa fa-align-left"></i>
						</a>
					</li>
				</ul>
				<!-- end navbar-right -->
			</div>
			<!-- end container-fluid -->
		</div>
		<!-- end #header -->
		
		<!-- begin #sidebar -->
		<div id="sidebar" class="sidebar">
			<!-- begin sidebar scrollbar -->
			<div data-scrollbar="true" data-height="100%">
				<!-- begin sidebar nav -->
				<ul class="nav">
				    <li class="nav-user">
				        <div class="image">
				            <img src="<?php echo $login_foto; ?>" alt="" />
				        </div>
				        <div class="info">
				            <div class="name dropdown">
				                <a href="javascript:;" data-toggle="dropdown"><?php echo $login_session; ?> <b class="caret"></b></a>
                                <ul class="dropdown-menu">
                                  
                                    <li><a href="logout.php">Keluar</a></li>
                                </ul>
				            </div>
				            <div class="position"><?php echo $login_lengkap; ?></div>
				        </div>
				    </li>
					<li class="nav-header">Navigasi</li>
					<li class="active has-sub">
						<a href="dashboard.php">
						    <i class="fa fa-home"></i>
						    <span>Dashboard <span class="label label-theme m-l-3">NEW</span></span>
					    </a></li>
				
					<li>
						<a href="daftar_user.php">
						    <i class="glyphicon glyphicon-user"></i>
						    <span>Data Pengguna</span>
					    </a>
					</li>
					<li>
						<a href="daftar_status.php">
						    <i class="glyphicon glyphicon-book"></i>
						    <span>Data Status</span>
					    </a>
					</li>
                    	<li>
						<a href="data_komentar.php">
						    <i class="glyphicon glyphicon-tasks"></i>
						    <span>Data Komentar</span>
					    </a>
					</li>
                    	<li>
						<a href="LOGOUT.php">
						    <i class="glyphicon glyphicon-log-out"></i>
						    <span>Keluar</span>
					    </a>
					</li>
				
				</ul>
				<!-- end sidebar nav -->
			</div>
			<!-- end sidebar scrollbar -->
		</div>
		<div class="sidebar-bg"></div>