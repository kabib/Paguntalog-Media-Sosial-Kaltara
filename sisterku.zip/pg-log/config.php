<?php
/*
 * variabel koneksi
 ***/
$db_host	= 'localhost';
$db_port	= '80';
$db_name	= 'sisterku';
$db_user	= 'root';
$db_pass	= '';

