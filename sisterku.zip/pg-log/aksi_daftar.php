<?php
include("../koneksi.php");
$query = "update akun set terverifikasi = '$_POST[selectBox]' where id_akun = '$_POST[tid]' ";
$result = mysql_query($query);

if ($result) {
	header("location: daftar_user.php");
}
else {
	echo "proses simpan gagal !.";
}
?>