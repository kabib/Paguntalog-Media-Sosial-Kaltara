<?php
 include '../koneksi.php';
  include 'kepala.php';

 ?>
			<div class="sidebar-bg"></div>
		<!-- end #sidebar -->
		
		<!-- begin #content -->
		<div id="content" class="content">
			<!-- begin breadcrumb -->
			<ol class="breadcrumb pull-right">
				<li><a href="javascript:;">Beranda</a></li>
				<li><a href="javascript:;">Data Komentar</a></li>

				<li class="active">Pilihan</li>
			</ol>
			<!-- end breadcrumb -->
			<!-- begin page-header -->
			<h1 class="page-header">Data Komentar <small>PaguntaLOG</small></h1>
			<!-- end page-header -->
			
			<!-- begin section-container -->
			<div class="section-container section-with-top-border">
                
                <!-- begin panel -->
                <div class="panel pagination-grey clearfix m-b-0">
                    <table id="data-table" data-order='[[1,"asc"]]' class="table table-bordered table-hover">
                        <thead>
                            <tr class="grey">
                                <th>Id Status</th>
                                <th>ID Komentator</th>
                                <th>Isi Komentar</th>
                                <th>Tanggal</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <?php 
include("../koneksi.php");
		$tampil = mysql_query("select * from komentar ORDER BY id_komentar DESC");
		while($data=mysql_fetch_array($tampil)){
		
			?>
                        <tbody>
                            <tr class="odd gradeX">
                                <td><?=$data['id_status']?></td>
                                <td><?=$data['id_komentator']?></td>
                                <td><?=$data['isi_komen']?></td>
                             	<td><?=$data['tanggal']?></td>
                                  <td><a href="hapus_komentar.php?id=<?php echo $data['id_komentar']; ?>" class="btn btn-default btn-xs"><i class="fa fa-cog"></i> Hapus</a></td>
                            </tr>
                        
                        </tbody>
                        <?php
						}
						?>
                    </table>
                </div>
                <!-- end panel -->
			</div>
			<!-- end section-container -->
			 
			<?php
  include 'kaki.php';

 ?>
          