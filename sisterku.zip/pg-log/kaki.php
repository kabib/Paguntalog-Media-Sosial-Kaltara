  <!-- begin #footer -->
            <div id="footer" class="footer">
                <span class="pull-right">
                    <a href="javascript:;" class="btn-scroll-to-top" data-click="scroll-top">
                        <i class="fa fa-arrow-up"></i> <span class="hidden-xs">Back to Top</span>
                    </a>
                </span>
                &copy; 2016 <b>PaguntaLOG</b> All Right Reserved
            </div>
            <!-- end #footer -->
		</div>
		<!-- end #content -->
		
		<!-- begin #sidebar-right -->
		<div id="sidebar-right" class="sidebar sidebar-right">
			<!-- begin sidebar scrollbar -->
			<div data-scrollbar="true" data-height="100%">
				<!-- begin sidebar-nav -->
                <ul class="nav nav-tabs" role="tablist">
                    <li class="width-half active"><a href="#today" data-toggle="tab">Hari Ini</a></li>
                    <li class="width-half"><a href="#notifications" data-toggle="tab">User Terbaru</a></li>
                </ul>
                <div class="tab-content">
                    <div class="tab-pane active" id="today">
                        <ul class="nav">
                       
                    
                            <li class="nav-header">Kelender</li>
                            <li>
                                <div id="schedule-calendar"></div>
                            </li>
                            <li class="divider"></li>
                            <li class="nav-header">Postingan</li>
                            <li>
                                <ul class="nav-post">
                                  <?php 
include("../koneksi.php");
		$tampil = mysql_query("select * from status");
		while($data=mysql_fetch_array($tampil)){
		
			?>
                                    <li>
                                        <div class="image">
                                            <img src="../<?=$data['gambar']?>" alt="" />
                                        </div>
                                        <div class="info">
                                            <div class="title"><?=$data['nama']?></div>
                                            <div class="time"><?=$data['isi']?></div>
                                        </div>
                                    </li>
                                    <?php
									}
									?>
                                   
                                </ul>
                            </li>
                            <li class="divider"></li>
                        </ul>
                    </div>
                    <div class="tab-pane" id="notifications">
                        <ul class="nav">
                            <li class="nav-header">User Terbaru</li>
                            <li>
                                  <ul class="nav-post">
                                  <?php 
include("../koneksi.php");
		$tampil = mysql_query("select * from akun");
		while($data=mysql_fetch_array($tampil)){
		
			?>
                                    <li>
                                        <div class="image">
                                            <img src="../images/<?=$data['foto']?>" alt="" />
                                        </div>
                                        <div class="info">
                                            <div class="title"><?=$data['namalengkap']?></div>
                                            <div class="time">@<?=$data['nama']?></div>
                                        </div>
                                    </li>
                                    <?php
									}
									?>
                                   
                                </ul>
                            </li>
                            
                        </ul>
                    </div>
                </div>
				<!-- end sidebar-nav -->
			</div>
			<!-- end sidebar scrollbar -->
		</div>
		<div class="sidebar-bg sidebar-right"></div>
		<!-- end #sidebar-right -->
	</div>
	<!-- end page container -->
	
   
    <!-- end theme-panel -->
	
	<!-- ================== BEGIN BASE JS ================== -->
	<script src="assets/plugins/jquery/jquery-1.9.1.min.js"></script>
	<script src="assets/plugins/jquery/jquery-migrate-1.1.0.min.js"></script>
	<script src="assets/plugins/jquery-ui/ui/minified/jquery-ui.min.js"></script>
	<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>

	<script src="assets/plugins/slimscroll/jquery.slimscroll.min.js"></script>
	<script src="assets/plugins/jquery-cookie/jquery.cookie.js"></script>
	<!-- ================== END BASE JS ================== -->
	
	<!-- ================== BEGIN PAGE LEVEL JS ================== -->
    <script src="assets/plugins/bootstrap-calendar/js/bootstrap_calendar.min.js"></script>
    <script src="assets/plugins/chart-js/chart.min.js"></script>
	<script src="assets/plugins/gritter/js/jquery.gritter.js"></script>
    <script src="assets/js/page-index-v2.demo.min.js"></script>
    <script src="assets/js/demo.min.js"></script>
    <script src="assets/js/apps.min.js"></script>
	<!-- ================== END PAGE LEVEL JS ================== -->
	
	<script>
		$(document).ready(function() {
		    App.init();
		    Demo.init();
		    PageDemo.init();
		});
	</script>
	<script>
      (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
      (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
      m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
      })(window,document,'script','../../../../www.google-analytics.com/analytics.js','ga');
    
      ga('create', 'UA-53034621-1', 'auto');
      ga('send', 'pageview');
    </script>
</body>
</html>
