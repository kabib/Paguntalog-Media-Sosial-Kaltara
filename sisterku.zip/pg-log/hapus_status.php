<?php
		 include("../koneksi.php");
$query = "delete from status where id_status = '$_GET[id]'";
$result = mysql_query($query);

if ($result) {
	header("location: daftar_status.php");
}
else {
	echo "proses hapus gagal !.";
}
?>
