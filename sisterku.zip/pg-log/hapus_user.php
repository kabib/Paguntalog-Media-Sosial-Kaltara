<?php
		 include("../koneksi.php");
$query = "delete from akun where id_akun = '$_GET[id]'";
$result = mysql_query($query);

if ($result) {
	header("location: daftar_user.php");
}
else {
	echo "proses hapus gagal !.";
}
?>
