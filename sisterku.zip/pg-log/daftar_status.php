<?php
 include '../koneksi.php';
  include 'kepala.php';

 ?>
			<div class="sidebar-bg"></div>
		<!-- end #sidebar -->
		
		<!-- begin #content -->
		<div id="content" class="content">
			<!-- begin breadcrumb -->
			<ol class="breadcrumb pull-right">
				<li><a href="javascript:;">Beranda</a></li>
				<li><a href="javascript:;">Data Status</a></li>

				<li class="active">Pilihan</li>
			</ol>
			<!-- end breadcrumb -->
			<!-- begin page-header -->
			<h1 class="page-header">Data Status <small>PaguntaLOG</small></h1>
			<!-- end page-header -->
			
			<!-- begin section-container -->
			<div class="section-container section-with-top-border">
                
                <!-- begin panel -->
                <div class="panel pagination-grey clearfix m-b-0">
                    <table id="data-table" data-order='[[1,"asc"]]' class="table table-bordered table-hover">
                        <thead>
                            <tr class="grey">
                                <th>Username</th>
                                <th>Isi Status</th>
                                <th>Foto</th>
                                <th>Tanggal</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <?php 
include("../koneksi.php");
		$tampil = mysql_query("select * from status ORDER BY id_status DESC");
		while($data=mysql_fetch_array($tampil)){
		
			?>
                        <tbody>
                            <tr class="odd gradeX">
                                <td><?=$data['nama']?></td>
                                <td><?=$data['isi']?></td>
                                <td><img src="../<?=$data['gambar']?>" width="249" height="153"></td>
                             	<td><?=$data['tanggal']?></td>
                                <td><a href="hapus_status.php?id=<?php echo $data['id_status']; ?>" class="btn btn-default btn-xs"><i class="fa fa-cog"></i> Hapus</a></td>
                            </tr>
                        
                        </tbody>
                        <?php
						}
						?>
                    </table>
                </div>
                <!-- end panel -->
			</div>
			<!-- end section-container -->
			 
			<?php
  include 'kaki.php';

 ?>
          