<?php
include('session.php');

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="img/favicon.png">
    <title>PaguntaLOG</title>
    <!-- Bootstrap core CSS -->
    <link href="bootstrap-3.3.5/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/animate.min.css" rel="stylesheet">
    <link href="font-awesome-4.4.0/css/font-awesome.min.css" rel="stylesheet">
    <link href="assets/css/timeline.css" rel="stylesheet">
    <script src="assets/js/jquery.1.11.1.min.js"></script>
    <script src="bootstrap-3.3.5/js/bootstrap.min.js"></script>
    <script src="assets/js/custom.js"></script>
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body class="animated fadeIn">

    <!-- Fixed navbar -->
    <nav class="navbar navbar-default navbar-fixed-top navbar-principal">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="profil.php">
            <img src="img/logo.png" class="img-logo">
            <b>PaguntaLOG</b>
          </a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
			<div class="col-md-5 col-sm-4">         
			 <form class="navbar-form" action="cari.php" method="post">
			    <div class="form-group" style="display:inline;">
			      <div class="input-group" style="display:table;">
			        <input class="form-control" name="search" placeholder="Cari" autocomplete="off" type="text">
			        <span class="input-group-addon" style="width:1%;">
			          <span class="glyphicon glyphicon-search"></span>
			        </span>
			      </div>
			    </div>
			  </form>
			</div>        
			<ul class="nav navbar-nav navbar-right">
				<li class="active">
					<a href="profil.php">
						<?php echo $login_session; ?>
						<img src="images/<?php echo $login_foto; ?>" class="img-nav">
					</a>
				</li>

					<li ><a href="mention.php"><i class="fa fa-globe"></i></a></li>
				<li><a href="logout.php"><i class="fa fa-user"></i> Keluar</a></li>				
			</ul>
        </div>
      </div>
    </nav>

    <!-- Timeline content -->
    <div class="container">
	    <!-- cover content -->
	    <div class="row">
	      <div class="col-md-10 no-paddin-xs">
	      	<!-- cover and profile image-->
	        <div class="col-md-12 col-sm-12 col-xs-12 cover-content">
				<div class="cover-container" style="background-image:url(images/<?php echo $login_cover; ?>);">
					<div class="social-cover"></div>
					<div class="social-desc">
					   <div class="desc-content">
					      <h1 class="fg-white text-shadow"><?php echo $login_alamat; ?></h1>
					      <h5 class="fg-white text-shadow">Handphone : <?php echo $login_nohp; ?></h5>
					      <div style="margin-top:50px;"></div>
					   </div>
					</div>
					<div class="social-avatar" >
					   <img class="img-avatar" src="images/<?php echo $login_foto; ?>" height="100" width="100">
					   <h4 class="fg-white text-center text-shadow"><?php echo $login_lengkap; ?>  <img src="<?php echo $login_terverifikasi; ?>" title="Akun Terverifikasi"></h4>
					   <h5 class="fg-white text-center" style="opacity:0.8;">@<?php echo $login_session; ?></h5>
					   <hr class="border-black75 text-shadow" style="border-width:2px;" >
					   <div class="text-center">
					    <button role="button" class="btn btn-inverse btn-outlined btn-retainBg btn-brightblue" type="button">
					      <span>ikuti aku</span>
					    </button>
					   </div>
					</div>
				</div>
	        </div><!-- end cover and profile image-->
	        <!-- cover menu -->
	        <div class="col-md-12  col-sm-12 col-xs-12">
	          <div class="panel-options">
	            <div class="navbar navbar-default navbar-cover">
	              <div class="container-fluid">
	                <div class="navbar-header">
	                  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#profile-opts-navbar">
	                    <span class="sr-only">Toggle navigation</span>
	                    <span class="icon-bar"></span>
	                    <span class="icon-bar"></span>
	                    <span class="icon-bar"></span>
	                  </button>
	                </div>

	                <div class="collapse navbar-collapse" id="profile-opts-navbar">
	                  <ul class="nav navbar-nav navbar-right">
	                    <li class="active"><a href="profil.php"><i class="fa fa-tasks"></i>Tembok Saya</a></li>
                         <li><a href="temboksemua.php"><i class="fa fa-tasks"></i>Tembok Semua</a></li>
	                    <li><a href="editakun.php?id=<?php echo $login_id; ?>"><i class="fa fa-info-circle"></i>Edit Akun</a></li>
	                    <li><a href="sahabat.php"><i class="fa fa-users"></i>Sahabat</a></li>
	                    <li><a href="gambar.php"><i class="fa fa-file-image-o"></i>Galeri</a></li>
	                   
	                  </ul>
	                </div>
	              </div>
	            </div>
	          </div>
	        </div><!-- cover menu -->
	      </div>
	    </div><!-- cover content -->

	    <div class="row">
	    	<div class="col-md-10 no-paddin-xs">
	    		<!-- left content (detail, frields, photos) -->
	    		<div class="col-md-5 user-detail no-paddin-xs">
	    			<!-- user detail -->
					<div class="panel panel-default panel-user-detail">
						<div class="panel-body">
						  <ul class="list-unstyled">
						    <li><i class="fa fa-suitcase"></i>Nama : <?php echo $login_lengkap; ?></li>
						    <li><i class="fa fa-calendar"></i>Alamat : <?php echo $login_alamat; ?></li>
                            <li><i class="fa fa-calendar"></i>No HP : <?php echo $login_nohp; ?></li>
						    <li><i class="fa fa-rss"></i>Tentang : <?php echo $login_tentang; ?></li>
						  </ul>
						</div>
						
					</div><!-- end user detail -->
					
					<!-- friends -->
					<div class="panel panel-white panel-friends">
						<div class="panel-heading">
						 
						  <h3 class="panel-title">Kenali Mereka </h3>
						</div>
						<div class="panel-body text-center">
						  <ul class="friends">
                            <?php 
		include("koneksi.php");
		$tampil = mysql_query("select * from akun ORDER BY id_akun DESC LIMIT 6");
		while($data=mysql_fetch_array($tampil)){
		
			?> 
						    <li>
						        <a href="temanku.php?id=<?php echo $data['id_akun']; ?>">
						            <img src="images/<?=$data['foto']?>" title="<?=$data['namalengkap']?>" class="img-responsive tip">
						        </a>
						    </li>
						   <?php
						   }
						   ?>
						  </ul>
						</div>
					</div><!-- end friends --> 
					<!-- photos -->
					<div class="panel panel-white">
						<div class="panel-heading">
						 
						  <h3 class="panel-title">Postingan</h3>
						</div>
						<div class="panel-body text-center">
						  <ul class="photos">
                          <?php 

		$tampil = mysql_query("select * from status WHERE nama = '$login_session' LIMIT 6 ");
		while($data=mysql_fetch_array($tampil)){
		
			?> 
						    <li>
						        <a href="#">
						          <img src="<?=$data['gambar']?>" alt="photo 1" class="img-responsive show-in-modal">
						        </a>
						    </li>
                            <?php
							}
							?>
                            
						
						  </ul>
						</div>
					</div><!-- end photos-->

										
	    		</div><!-- end left content (detail, frields, photos) -->

	    		<!-- right content-->
	    		<div class="col-md-7 no-paddin-xs">
	    			<!-- add post form-->
        			<div class="panel profile-info panel-success">
			         
                      <div class="panel-footer">
			      
			              <ul class="nav nav-pills">
			                
			          
			          <div class="panel-footer">
			        
			              </div>
			          
                        
                      
                      
                      
                      <form method="post" action="posting_aksi.php" name="frmBerita" enctype="multipart/form-data">
  
  <div class="control-group">
   
     
      
      <p>  <input type="file" id="inputGambar" name="gbr_berita" required><br/>
        <textarea class="form-control input-lg p-text-area" rows="5" cols="40" name="isi" required id="status"></textarea>
        </p>
  </div>
  <div class="control-group">
    <div class="controls">
      <div align="left">
 
         <input name="id_akun" type="hidden" value="<?php echo $login_session; ?>">
         <input name="nama" type="hidden" value="<?php echo $login_id; ?>">
              <input name="foto_akun" type="hidden" value="<?php echo $login_foto; ?>">
        </div>
    </div>
  </div>
  <div class="control-group">
    <div class="controls">
      <div align="right"></div>
      <button type="submit" class="btn btn-primary">
      <div align="left">Posting Bah</div>
      </button>
    </div>
  </div>
</form>
           
                           
			          </div>
			        </div><!-- end add post form-->

			        <!-- first post-->
                     <?php 

		$tampil = mysql_query("select * from status WHERE nama = '$login_session' ORDER BY id_status DESC ");
		while($data=mysql_fetch_array($tampil)){
		
			?> 
					<div class="panel panel-white post panel-shadow">
					  <div class="post-heading">
                      
					      <div class="pull-left image">
					          <img src="images/<?php echo $login_foto; ?>" class="avatar" alt="user profile image">
					      </div>
					      <div class="pull-left meta">
					          <div class="title h5">
					              <a href="temanku.php?id=<?php echo $data['id_akun']; ?>" class="post-user-name"><?php echo $login_session; ?></a>
					          </div>
					          <h6 class="text-muted time"><?=$data['tanggal']?></h6>
					      </div>
					  </div>
					  <div class="post-image">
					     <img src="<?=$data['gambar']?>" class="image show-in-modal" alt="image post">
					  </div>
					  <div class="post-description">
					      <p><?=$data['isi']?> </p>
					    
					  </div>
					  <div class="post-footer">
                          
                          <form action="komentar.php?id_status=<?php echo $data['id_status'];?>" method="post">
                                        <input class="form-control" type="text" name="komentar" placeholder="Komentar..."></textarea>
       									  <input name="nama" type="hidden" value="<?php echo $login_id; ?>">
							</form>
					      <ul class="comments-list">
                          <?php
 		$query3 = mysql_query("SELECT komentar.*,akun.*,status.* FROM komentar,akun,status where komentar.id_status=status.id_status and status.id_akun=akun.id_akun and status.id_status = '$data[id_status]' order by status.id_status desc");
 			 while($row1=mysql_fetch_array($query3)){ 
 			 $id_komentar_status=$row1['id_komentar'];
 			 $isi_komentar_status=$row1['isi_komen'];
			
 			 $id_komentator=$row1['id_komentator'];
			  $tgl_komen=$row1['tanggal'];
		$query4=mysql_fetch_array(mysql_query("select * from akun where id_akun='$id_komentator'"));
 			 $nama_depan4=$query4['nama'];
 			 $foto4=$query4['foto'];
			  ?>
					          <li class="comment">
					              <a class="pull-left" href="#">
					                  <img class="avatar" src="images/<?php echo $foto4;?>" alt="avatar">
					              </a>
					              <div class="comment-body">
					                  <div class="comment-heading">
					                      <h4 class="comment-user-name"><a href="#"><?php echo $nama_depan4;?></a></h4>
					                      <h5 class="time"><?php  echo $tgl_komen;?></h5>
					                  </div>
					                  <p><?php echo $isi_komentar_status; ?></p>
					              </div>
					          </li>
                              <?php
							  }
							  ?>
					        
					      </ul>
					  </div>
					</div><!-- first post-->
<?php
}
?>
			    
				
	    		</div><!-- end right content-->	
	    	</div>
	    </div>   
    </div>

   
    
    <footer class="welcome-footer">
      <div class="container">
        <p>
          <div class="footer-links">

            <a href="#">Tim Pengembang</a> | 
            <a href="#">Kontak</a> | 
            <a href="#">Tentang Kami</a>
          </div>   
          Copyright &copy; Tarakan Creative - All rights reserved       
        </p>
      </div>
    </footer>
<script type="text/javascript">
  var _gaq = [
    ['_setAccount', 'UA-49755460-1'],
    ['_trackPageview']
  ];
  (function (d, t) {
    var g = d.createElement(t), s = d.getElementsByTagName(t)[0];
    g.src = ('https:' == location.protocol ? '//ssl' : '//www') + '.google-analytics.com/ga.js';
    s.parentNode.insertBefore(g, s)
  }(document, 'script'));
</script>	
  </body>
</html>