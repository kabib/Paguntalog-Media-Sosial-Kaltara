<?php
include("koneksi.php"); 
$isi  = $_POST['isi'];
$tanggal	= date('d M Y H:i');
$id_akun = $_POST['id_akun'];
$nama = $_POST['nama'];
$foto_akun = $_POST['foto_akun'];

#tangkap gambar
$namafolder="gambar/"; //folder tempat menyimpan file
if (!empty($_FILES["gbr_berita"]["tmp_name"]))
{
    $jenis_gambar=$_FILES['gbr_berita']['type'];
    if($jenis_gambar=="image/jpeg" || $jenis_gambar=="image/jpg" || $jenis_gambar=="image/gif" || $jenis_gambar=="image/png")
    {           
        $gambar= $namafolder . basename($_FILES['gbr_berita']['name']);       
        if (move_uploaded_file($_FILES['gbr_berita']['tmp_name'], $gambar)) {
           mysql_query("insert into status values ('','$isi','$tanggal','$nama','$id_akun','$gambar','$foto_akun')",$koneksi); 
		   ?>
				<script language="javascript">
                    alert('Berhasil menambahkan');
					document.location="profil.php";
                  
                </script>
   			<?php
        } else {
         	?>
				<script language="javascript">
                    alert('Gagal menambahkan');
                	document.location="profil.php";
                </script>
   			<?php
        }
   } else {
        ?>
			<script language="javascript">
                alert('Gambar harus berformat .jpg .png .gif');
             		document.location="profil.php";
            </script>
   		<?php
   }
} else {
    echo "Anda belum memilih gambar";
}
?>